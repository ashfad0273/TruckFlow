/**
 * TruckFlow - Trucking Logistics Dashboard
 * Main JavaScript File (script.js)
 * 
 * This script handles:
 * - Modal management (open/close, dynamic rows)
 * - Date filtering logic
 * - Chart.js visualization (dual-axis)
 * - Data submission to Google Sheets
 * - UI interactivity and state management
 */

// ============================================
// CONFIGURATION & STATE MANAGEMENT
// ============================================

/**
 * Google Apps Script Web App URL
 * Replace this with your actual deployed web app URL
 */
const WEB_APP_URL = 'https://script.google.com/macros/s/AKfycbxZdBX6-d1oIiq8nUM5HECHOiojHnpyK-ODniCt9amippNE-02Vy9BkvbQrF3ip3rt8-A/exec';

/**
 * Application state object
 * Centralized state management for the dashboard
 */
const AppState = {
    currentFilter: 'today',
    customDateRange: {
        from: null,
        to: null
    },
    chart: null,
    transactions: [],
    isLoading: false
};

// ============================================
// DOCUMENT READY - MAIN ENTRY POINT
// ============================================

$(document).ready(function() {
    console.log('🚛 TruckFlow Dashboard Initializing...');
    
    // Initialize the application
    initializeApp();
    
    // Set up all event listeners
    setupModalEventListeners();
    setupFilterEventListeners();
    setupChartEventListeners();
    setupDataSubmissionListeners();
    setupKeyboardNavigation();
    
    console.log('✅ TruckFlow Dashboard Ready');
});

/**
 * Initialize the application
 * Sets up initial state, chart, and loads data
 */
function initializeApp() {
    // Initialize the analytics chart
    initializeChart();
    
    // Set today's date as default for date inputs
    setDefaultDates();
    
    // Set initial active filter state
    setActiveFilter($('#filterToday'), 'today');
    
    // Load initial dashboard data from Google Sheets
    loadDashboardData('today');
}

/**
 * Load dashboard data on initial page load
 * @param {string} filter - Filter type to apply
 */
function loadDashboardData(filter) {
    const today = new Date();
    let startDate, endDate;
    
    switch (filter) {
        case 'today':
            startDate = formatDate(today);
            endDate = formatDate(today);
            break;
        case 'week':
            const startOfWeek = new Date(today);
            startOfWeek.setDate(today.getDate() - today.getDay());
            startDate = formatDate(startOfWeek);
            endDate = formatDate(today);
            break;
        case 'month':
            const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
            startDate = formatDate(startOfMonth);
            endDate = formatDate(today);
            break;
        default:
            startDate = formatDate(today);
            endDate = formatDate(today);
    }
    
    fetchFilteredData(startDate, endDate);
}

// ============================================
// MODAL MANAGEMENT
// ============================================

/**
 * Set up event listeners for modal interactions
 */
function setupModalEventListeners() {
    // Open modal when "Add Daily Entry" button is clicked
    $('#openModalBtn').on('click', function() {
        openModal();
    });
    
    // Close modal when close button (X) is clicked
    $('#closeModalBtn').on('click', function() {
        closeModal();
    });
    
    // Close modal when cancel button is clicked
    $('#cancelModalBtn').on('click', function() {
        closeModal();
    });
    
    // Close modal when clicking on backdrop
    $('#modalBackdrop').on('click', function() {
        closeModal();
    });
    
    // Prevent modal content clicks from closing modal
    $('#entryModal .relative').on('click', function(e) {
        e.stopPropagation();
    });
    
    // Close modal on Escape key press
    $(document).on('keydown', function(e) {
        if (e.key === 'Escape' && !$('#entryModal').hasClass('hidden')) {
            closeModal();
        }
    });
    
    // Add new row when "Add Another Row" button is clicked
    $('#addRowBtn').on('click', function() {
        addEntryRow();
    });
    
    // Delete row using event delegation (works for dynamically added rows)
    $('#modalBody').on('click', '.delete-row-btn', function(e) {
        e.preventDefault();
        deleteEntryRow($(this));
    });


// Date toggle buttons in modal
$('#dateTodayBtn').on('click', function() {
    $(this).addClass('bg-indigo-600 text-white').removeClass('text-slate-600 hover:bg-slate-50');
    $('#dateSpecificBtn').removeClass('bg-indigo-600 text-white').addClass('text-slate-600 hover:bg-slate-50');
    $('#specificDateContainer').addClass('hidden');
    $('#todayDateDisplay').removeClass('hidden');
});

$('#dateSpecificBtn').on('click', function() {
    $(this).addClass('bg-indigo-600 text-white').removeClass('text-slate-600 hover:bg-slate-50');
    $('#dateTodayBtn').removeClass('bg-indigo-600 text-white').addClass('text-slate-600 hover:bg-slate-50');
    $('#specificDateContainer').removeClass('hidden');
    $('#todayDateDisplay').addClass('hidden');
    // Set default date to today
    $('#entryDate').val(formatDate(new Date()));
});

// Update the openModal function to show today's date:
function openModal() {
    const $modal = $('#entryModal');
    $modal.removeClass('hidden');
    $('body').addClass('overflow-hidden');
    
    // Set today's date display
    const today = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    $('#todayDateDisplay').text(today.toLocaleDateString('en-US', options));
    
    // Reset date toggle to "Today"
    $('#dateTodayBtn').addClass('bg-indigo-600 text-white').removeClass('text-slate-600 hover:bg-slate-50');
    $('#dateSpecificBtn').removeClass('bg-indigo-600 text-white').addClass('text-slate-600 hover:bg-slate-50');
    $('#specificDateContainer').addClass('hidden');
    $('#todayDateDisplay').removeClass('hidden');
    
    setTimeout(function() {
        $('#modalBody input[name="entryName"]').first().focus();
    }, 100);
    
    console.log('📝 Modal opened');
}

// Update collectEntryData to get the selected date:
function collectEntryData() {
    const entries = [];
    const timestamp = new Date().toISOString();
    
    // Get the selected date
    let dateString;
    if ($('#specificDateContainer').hasClass('hidden')) {
        // "Today" is selected
        dateString = formatDate(new Date());
    } else {
        // Specific date is selected
        dateString = $('#entryDate').val() || formatDate(new Date());
    }
    
    $('#modalBody .entry-row').each(function(index) {
        const $row = $(this);
        const name = $row.find('input[name="entryName"]').val().trim();
        const amountRaw = $row.find('input[name="entryAmount"]').val();
        const trucksRaw = $row.find('input[name="entryTrucks"]').val();
        const status = $row.find('select[name="entryStatus"]').val();
        
        const amount = parseFloat(amountRaw) || 0;
        const truckCount = parseInt(trucksRaw, 10) || 0;
        
        if (name) {
            entries.push({
                name: name,
                amount: amount,
                truckCount: truckCount,
                status: status,
                date: dateString,
                timestamp: timestamp
            });
        }
    });
    
    return entries;
}

// Update the updateTransactionsTable function to include the Date column:
function updateTransactionsTable(transactions) {
    const $tbody = $('#transactionsBody');
    $tbody.empty();
    
    if (!transactions || transactions.length === 0) {
        $tbody.append(`
            <tr id="emptyStateRow">
                <td colspan="5" class="px-6 py-12 text-center">
                    <div class="flex flex-col items-center">
                        <div class="bg-slate-100 rounded-full p-4 mb-4">
                            <svg class="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                        </div>
                        <p class="text-slate-600 font-medium mb-1">No transactions found</p>
                        <p class="text-sm text-slate-400">Add your first entry to get started</p>
                    </div>
                </td>
            </tr>
        `);
        $('#transactionCount').text('0 entries');
        return;
    }
    
    // Avatar background colors
    const avatarColors = [
        'bg-indigo-100 text-indigo-600',
        'bg-purple-100 text-purple-600',
        'bg-blue-100 text-blue-600',
        'bg-cyan-100 text-cyan-600',
        'bg-teal-100 text-teal-600',
        'bg-emerald-100 text-emerald-600',
        'bg-amber-100 text-amber-600',
        'bg-orange-100 text-orange-600',
        'bg-rose-100 text-rose-600',
        'bg-pink-100 text-pink-600'
    ];
    
    transactions.forEach(function(transaction, index) {
        const initials = getInitials(transaction.name);
        const isOutstanding = transaction.status === 'Outstanding';
        const avatarColor = avatarColors[index % avatarColors.length];
        
        const rowClass = isOutstanding 
            ? 'bg-rose-50/50 hover:bg-rose-50' 
            : 'hover:bg-slate-50';
        const statusBgClass = isOutstanding 
            ? 'bg-rose-100 text-rose-700' 
            : 'bg-emerald-100 text-emerald-700';
        const statusDotClass = isOutstanding 
            ? 'bg-rose-500' 
            : 'bg-emerald-500';
        
        const formattedAmount = '$' + formatNumber(transaction.amount);
        const formattedDate = transaction.formattedDate || formatDisplayDate(transaction.date);
        
        const rowHtml = `
            <tr class="${rowClass} transition-colors duration-150">
                <td class="px-6 py-4 text-sm text-slate-500 whitespace-nowrap">${escapeHtml(formattedDate)}</td>
                <td class="px-6 py-4">
                    <div class="flex items-center">
                        <div class="w-8 h-8 ${avatarColor} rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                            <span class="text-xs font-bold">${escapeHtml(initials)}</span>
                        </div>
                        <span class="font-medium text-slate-800 truncate">${escapeHtml(transaction.name)}</span>
                    </div>
                </td>
                <td class="px-6 py-4 text-center text-slate-600 font-medium">${transaction.truckCount}</td>
                <td class="px-6 py-4 text-right text-slate-800 font-bold">${formattedAmount}</td>
                <td class="px-6 py-4">
                    <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold ${statusBgClass}">
                        <span class="w-1.5 h-1.5 ${statusDotClass} rounded-full mr-1.5"></span>
                        ${transaction.status}
                    </span>
                </td>
            </tr>
        `;
        
        $tbody.append(rowHtml);
    });
    
    const count = transactions.length;
    $('#transactionCount').text(`${count} ${count === 1 ? 'entry' : 'entries'}`);
    console.log('📋 Transactions table updated');
}

// Add this helper function if not already present:
function formatDisplayDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString + 'T00:00:00');
    const options = { month: 'short', day: 'numeric', year: 'numeric' };
    return date.toLocaleDateString('en-US', options);
}

// Update addEntryRow for the new structure:
function addEntryRow() {
    const $template = $('#entryRowTemplate');
    const $modalBody = $('#modalBody');
    
    if ($template.length === 0) {
        console.error('Entry row template not found');
        return;
    }
    
    const templateContent = $template.html();
    const $newRow = $(templateContent);
    
    $modalBody.append($newRow);
    $newRow.hide().fadeIn(200);
    $newRow.find('input[name="entryName"]').focus();
    
    console.log('➕ New entry row added');
}

// Update deleteEntryRow for the new structure:
function deleteEntryRow($button) {
    const $row = $button.closest('.entry-row');
    const $modalBody = $('#modalBody');
    const rowCount = $modalBody.find('.entry-row').length;
    
    if (rowCount <= 1) {
        $row.find('input').val('');
        $row.find('select').prop('selectedIndex', 0);
        $row.find('input[name="entryName"]').focus();
        showNotification('At least one entry row is required', 'warning');
        return;
    }
    
    $row.fadeOut(200, function() {
        $(this).remove();
        console.log('➖ Entry row deleted');
    });
}

// Update resetModalForm for the new structure:
function resetModalForm() {
    const $modalBody = $('#modalBody');
    $modalBody.find('.entry-row').not(':first').remove();
    $modalBody.find('input').val('');
    $modalBody.find('select').prop('selectedIndex', 0);
}
}

/**
 * Open the entry modal
 * Removes the 'hidden' class and sets up focus
 */
function openModal() {
    const $modal = $('#entryModal');
    
    // Remove hidden class to show modal
    $modal.removeClass('hidden');
    
    // Prevent body scrolling when modal is open
    $('body').addClass('overflow-hidden');
    
    // Focus on the first input field after a brief delay
    setTimeout(function() {
        $('#modalBody input[name="entryName"]').first().focus();
    }, 100);
    
    console.log('📝 Modal opened');
}

/**
 * Close the entry modal
 * Adds the 'hidden' class and resets the form
 */
function closeModal() {
    const $modal = $('#entryModal');
    
    // Add hidden class to hide modal
    $modal.addClass('hidden');
    
    // Re-enable body scrolling
    $('body').removeClass('overflow-hidden');
    
    // Reset modal form to initial state
    resetModalForm();
    
    console.log('📝 Modal closed');
}

/**
 * Reset the modal form to its initial state
 * Removes all rows except the first one and clears all inputs
 */
function resetModalForm() {
    const $modalBody = $('#modalBody');
    
    // Remove all rows except the first one
    $modalBody.find('.entry-row').not(':first').remove();
    
    // Clear all input fields in the remaining row
    $modalBody.find('input').val('');
    
    // Reset dropdown to first option (Paid)
    $modalBody.find('select').prop('selectedIndex', 0);
}

/**
 * Add a new entry row to the modal table
 * Clones the template and appends to modal body
 */
function addEntryRow() {
    const $template = $('#entryRowTemplate');
    const $modalBody = $('#modalBody');
    
    // Check if template exists
    if ($template.length === 0) {
        console.error('Entry row template not found');
        return;
    }
    
    // Clone the template content
    const templateContent = $template.html();
    const $newRow = $(templateContent);
    
    // Append the new row to the modal body
    $modalBody.append($newRow);
    
    // Add subtle fade-in animation
    $newRow.hide().fadeIn(200);
    
    // Focus on the name input of the new row
    $newRow.find('input[name="entryName"]').focus();
    
    console.log('➕ New entry row added');
}

/**
 * Delete a specific entry row from the modal
 * Uses event delegation to handle dynamically added rows
 * @param {jQuery} $button - The delete button that was clicked
 */
function deleteEntryRow($button) {
    const $row = $button.closest('.entry-row');
    const $modalBody = $('#modalBody');
    const rowCount = $modalBody.find('.entry-row').length;
    
    // Prevent deleting the last remaining row
    if (rowCount <= 1) {
        // Instead of deleting, just clear the inputs
        $row.find('input').val('');
        $row.find('select').prop('selectedIndex', 0);
        $row.find('input[name="entryName"]').focus();
        
        // Show a subtle notification
        showNotification('At least one entry row is required', 'warning');
        return;
    }
    
    // Animate row removal
    $row.fadeOut(200, function() {
        $(this).remove();
        console.log('➖ Entry row deleted');
    });
}

// ============================================
// DATE FILTERING LOGIC
// ============================================

/**
 * Set up event listeners for filter buttons and date range controls
 */
function setupFilterEventListeners() {
    // Today filter button
    $('#filterToday').on('click', function() {
        setActiveFilter($(this), 'today');
        applyDateFilter('today');
    });
    
    // This Week filter button
    $('#filterWeek').on('click', function() {
        setActiveFilter($(this), 'week');
        applyDateFilter('week');
    });
    
    // This Month filter button
    $('#filterMonth').on('click', function() {
        setActiveFilter($(this), 'month');
        applyDateFilter('month');
    });
    
    // Custom Range toggle button
    $('#customRangeBtn').on('click', function() {
        toggleCustomRangeFields();
    });
    
    // Apply custom date range button
    $('#applyDateRange').on('click', function() {
        applyCustomDateRange();
    });
    
    // Apply on Enter key in date inputs
    $('#dateFrom, #dateTo').on('keypress', function(e) {
        if (e.key === 'Enter') {
            applyCustomDateRange();
        }
    });
}

/**
 * Set the active state for filter buttons
 * Updates visual styling and application state
 * @param {jQuery} $activeButton - The button to set as active
 * @param {string} filterType - The type of filter selected
 */
function setActiveFilter($activeButton, filterType) {
    // Define all preset filter buttons
    const $filterButtons = $('#filterToday, #filterWeek, #filterMonth');
    
    // Remove active state from all filter buttons
    $filterButtons
        .removeClass('bg-indigo-600 text-white')
        .addClass('text-slate-600 hover:bg-slate-100');
    
    // Add active state to clicked button
    $activeButton
        .addClass('bg-indigo-600 text-white')
        .removeClass('text-slate-600 hover:bg-slate-100');
    
    // Update application state
    AppState.currentFilter = filterType;
    
    // Hide custom range fields when a preset is selected
    $('#customRangeContainer').addClass('hidden');
    
    console.log(`📅 Filter set to: ${filterType}`);
}

/**
 * Toggle visibility of custom date range input fields
 */
function toggleCustomRangeFields() {
    const $container = $('#customRangeContainer');
    const $filterButtons = $('#filterToday, #filterWeek, #filterMonth');
    
    // Toggle the hidden class
    $container.toggleClass('hidden');
    
    // If showing custom range fields
    if (!$container.hasClass('hidden')) {
        // Remove active state from preset filter buttons
        $filterButtons
            .removeClass('bg-indigo-600 text-white')
            .addClass('text-slate-600 hover:bg-slate-100');
        
        // Update state
        AppState.currentFilter = 'custom';
        
        // Focus on the "From" date input
        $('#dateFrom').focus();
        
        console.log('📅 Custom range fields shown');
    } else {
        console.log('📅 Custom range fields hidden');
    }
}

/**
 * Apply date filter based on the selected preset type
 * Calculates date range and triggers data fetch
 * @param {string} filterType - 'today', 'week', or 'month'
 */
function applyDateFilter(filterType) {
    const today = new Date();
    let startDate, endDate;
    
    switch (filterType) {
        case 'today':
            startDate = formatDate(today);
            endDate = formatDate(today);
            break;
            
        case 'week':
            // Get the start of the current week (Sunday)
            const startOfWeek = new Date(today);
            startOfWeek.setDate(today.getDate() - today.getDay());
            startDate = formatDate(startOfWeek);
            endDate = formatDate(today);
            break;
            
        case 'month':
            // Get the start of the current month
            const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
            startDate = formatDate(startOfMonth);
            endDate = formatDate(today);
            break;
            
        default:
            startDate = formatDate(today);
            endDate = formatDate(today);
    }
    
    console.log(`📅 Applying ${filterType} filter: ${startDate} to ${endDate}`);
    
    // Update state with calculated date range
    AppState.customDateRange = { from: startDate, to: endDate };
    
    // Fetch filtered data from API
    fetchFilteredData(startDate, endDate);
}

/**
 * Apply custom date range filter
 * Validates and captures values from date inputs
 */
function applyCustomDateRange() {
    const startDate = $('#dateFrom').val();
    const endDate = $('#dateTo').val();
    
    // Validation: Check if both dates are provided
    if (!startDate || !endDate) {
        showNotification('Please select both start and end dates', 'error');
        return;
    }
    
    // Validation: Check if start date is before end date
    if (new Date(startDate) > new Date(endDate)) {
        showNotification('Start date cannot be after end date', 'error');
        return;
    }
    
    // Log the custom date range
    console.log('📅 Custom Date Range Applied:');
    console.log(`   From: ${startDate}`);
    console.log(`   To: ${endDate}`);
    
    // Update application state
    AppState.currentFilter = 'custom';
    AppState.customDateRange = { from: startDate, to: endDate };
    
    // Fetch filtered data from API
    fetchFilteredData(startDate, endDate);
    
    // Show success notification
    showNotification('Custom date range applied', 'success');
}

/**
 * Set default dates for the date input fields
 * Sets "From" to 7 days ago and "To" to today
 */
function setDefaultDates() {
    const today = new Date();
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    
    $('#dateFrom').val(formatDate(weekAgo));
    $('#dateTo').val(formatDate(today));
}

/**
 * Format a Date object to YYYY-MM-DD string
 * Required format for HTML date inputs
 * @param {Date} date - Date object to format
 * @returns {string} Formatted date string (YYYY-MM-DD)
 */
function formatDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

/**
 * Fetch filtered data from the Google Apps Script API
 * @param {string} startDate - Start date in YYYY-MM-DD format
 * @param {string} endDate - End date in YYYY-MM-DD format
 */
function fetchFilteredData(startDate, endDate) {
    console.log(`🔄 Fetching data from ${startDate} to ${endDate}...`);
    
    // Set loading state
    AppState.isLoading = true;
    showLoadingState(true);
    
    // Build the API URL with parameters
    const url = `${WEB_APP_URL}?action=getFilteredData&filter=custom&start=${startDate}&end=${endDate}`;
    
    fetch(url)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('✅ Filtered data received:', data);
            AppState.isLoading = false;
            showLoadingState(false);
            
            if (data.status === 'success') {
                // Update dashboard components with new data
                updateDashboard(data);
                AppState.transactions = data.tableData || [];
            } else {
                throw new Error(data.message || 'Failed to fetch data');
            }
        })
        .catch(error => {
            console.error('❌ Error fetching filtered data:', error);
            AppState.isLoading = false;
            showLoadingState(false);
            showNotification('Failed to fetch data. Please try again.', 'error');
        });
}

/**
 * Show/hide loading state on dashboard elements
 * @param {boolean} isLoading - Whether to show loading state
 */
function showLoadingState(isLoading) {
    if (isLoading) {
        // Add loading opacity to cards and table
        $('#kpiSection, #transactionsTable').addClass('opacity-50');
        $('#transactionCount').text('Loading...');
    } else {
        $('#kpiSection, #transactionsTable').removeClass('opacity-50');
    }
}

// ============================================
// CHART.JS INTEGRATION
// ============================================

/**
 * Set up event listeners for chart controls
 */
function setupChartEventListeners() {
    // Chart period selector dropdown change
    $('#chartPeriod').on('change', function() {
        const period = $(this).val();
        updateChartPeriod(period);
    });
}

/**
 * Initialize the dual-axis analytics chart
 * Creates a combined bar chart (stacked) for amounts and line chart for truck count
 */
function initializeChart() {
    const ctx = document.getElementById('analyticsChart');
    
    // Check if canvas element exists
    if (!ctx) {
        console.error('❌ Chart canvas element (#analyticsChart) not found');
        return;
    }
    
    // Generate dummy data for 7 days (will be replaced by API data)
    const labels = generateLast7DaysLabels();
    
    // Initial empty data
    const chartData = {
        paidAmount: [0, 0, 0, 0, 0, 0, 0],
        outstandingAmount: [0, 0, 0, 0, 0, 0, 0],
        truckCount: [0, 0, 0, 0, 0, 0, 0]
    };
    
    // Chart.js configuration
    const config = {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                // Dataset 1: Paid Amount (Bar - Stacked)
                {
                    label: 'Paid Amount',
                    data: chartData.paidAmount,
                    backgroundColor: 'rgba(16, 185, 129, 0.85)', // Emerald 500
                    borderColor: 'rgba(16, 185, 129, 1)',
                    borderWidth: 1,
                    borderRadius: 4,
                    borderSkipped: false,
                    stack: 'amounts',
                    yAxisID: 'y',
                    order: 2
                },
                // Dataset 2: Outstanding Amount (Bar - Stacked)
                {
                    label: 'Outstanding Amount',
                    data: chartData.outstandingAmount,
                    backgroundColor: 'rgba(244, 63, 94, 0.85)', // Rose 500
                    borderColor: 'rgba(244, 63, 94, 1)',
                    borderWidth: 1,
                    borderRadius: 4,
                    borderSkipped: false,
                    stack: 'amounts',
                    yAxisID: 'y',
                    order: 3
                },
                // Dataset 3: Truck Count (Line - Right Y-Axis)
                {
                    label: 'Truck Count',
                    data: chartData.truckCount,
                    type: 'line',
                    borderColor: 'rgba(99, 102, 241, 1)', // Indigo 500
                    backgroundColor: 'rgba(99, 102, 241, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4, // Smooth curve
                    pointBackgroundColor: 'rgba(99, 102, 241, 1)',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 7,
                    yAxisID: 'y1',
                    order: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false
            },
            plugins: {
                // Hide default legend (using custom HTML legend)
                legend: {
                    display: false
                },
                // Tooltip styling
                tooltip: {
                    backgroundColor: 'rgba(30, 41, 59, 0.95)', // Slate 800
                    titleColor: '#ffffff',
                    bodyColor: '#ffffff',
                    padding: 12,
                    cornerRadius: 8,
                    titleFont: {
                        size: 13,
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 12
                    },
                    displayColors: true,
                    boxWidth: 12,
                    boxHeight: 12,
                    boxPadding: 4,
                    callbacks: {
                        // Custom label formatting
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.dataset.label === 'Truck Count') {
                                label += context.parsed.y + ' trucks';
                            } else {
                                label += '$' + context.parsed.y.toLocaleString();
                            }
                            return label;
                        }
                    }
                }
            },
            scales: {
                // X-Axis configuration
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: '#64748b', // Slate 500
                        font: {
                            size: 11,
                            weight: '500'
                        }
                    },
                    border: {
                        display: false
                    }
                },
                // Y-Axis (Left) - Amount in dollars
                y: {
                    type: 'linear',
                    position: 'left',
                    stacked: true,
                    grid: {
                        color: 'rgba(226, 232, 240, 0.6)', // Slate 200
                        drawBorder: false
                    },
                    ticks: {
                        color: '#64748b',
                        font: {
                            size: 11
                        },
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        },
                        maxTicksLimit: 6
                    },
                    border: {
                        display: false
                    }
                },
                // Y1-Axis (Right) - Truck count
                y1: {
                    type: 'linear',
                    position: 'right',
                    grid: {
                        drawOnChartArea: false // Don't draw grid lines for right axis
                    },
                    ticks: {
                        color: '#6366f1', // Indigo 500
                        font: {
                            size: 11,
                            weight: '500'
                        },
                        callback: function(value) {
                            return value;
                        },
                        maxTicksLimit: 6
                    },
                    border: {
                        display: false
                    }
                }
            }
        }
    };
    
    // Create chart instance and store in application state
    AppState.chart = new Chart(ctx, config);
    
    console.log('📊 Analytics chart initialized');
}

/**
 * Generate labels for the last 7 days
 * @returns {string[]} Array of formatted day labels
 */
function generateLast7DaysLabels() {
    const labels = [];
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    
    for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dayName = dayNames[date.getDay()];
        const dayNum = date.getDate();
        labels.push(`${dayName} ${dayNum}`);
    }
    
    return labels;
}

/**
 * Update chart data based on selected period
 * @param {string} period - 'week', 'month', or 'year'
 */
function updateChartPeriod(period) {
    console.log(`📊 Updating chart to show: ${period}`);
    
    const today = new Date();
    let startDate, endDate;
    
    switch (period) {
        case 'week':
            const startOfWeek = new Date(today);
            startOfWeek.setDate(today.getDate() - 6);
            startDate = formatDate(startOfWeek);
            endDate = formatDate(today);
            break;
            
        case 'month':
            const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
            startDate = formatDate(startOfMonth);
            endDate = formatDate(today);
            break;
            
        case 'year':
            const startOfYear = new Date(today.getFullYear(), 0, 1);
            startDate = formatDate(startOfYear);
            endDate = formatDate(today);
            break;
            
        default:
            return;
    }
    
    // Fetch data for the selected period
    fetchFilteredData(startDate, endDate);
}

/**
 * Update chart with new data from API
 * @param {Object} chartData - Object containing labels and data arrays
 */
function updateChartData(chartData) {
    if (!AppState.chart || !chartData) return;
    
    AppState.chart.data.labels = chartData.labels || [];
    AppState.chart.data.datasets[0].data = chartData.paidAmount || [];
    AppState.chart.data.datasets[1].data = chartData.outstandingAmount || [];
    AppState.chart.data.datasets[2].data = chartData.truckCount || [];
    
    AppState.chart.update('active');
    console.log('📊 Chart updated with new data');
}

// ============================================
// DATA SUBMISSION (SAVING TO SHEET)
// ============================================

/**
 * Set up event listeners for data submission
 */
function setupDataSubmissionListeners() {
    // Save entries button click
    $('#saveEntries').on('click', function() {
        saveEntriesToSheet();
    });
}

/**
 * Save entries from modal to Google Sheet
 * Collects all entry data, validates, and submits via API
 */
function saveEntriesToSheet() {
    // Collect entry data from all rows
    const entries = collectEntryData();
    
    // Validate that we have at least one valid entry
    if (entries.length === 0) {
        showNotification('Please add at least one valid entry with a name', 'error');
        return;
    }
    
    // Log the collected data to console
    console.log('===== ENTRIES TO SAVE =====');
    console.log('Total entries:', entries.length);
    console.log(JSON.stringify(entries, null, 2));
    console.log('===========================');
    
    // Get reference to save button for loading state
    const $saveBtn = $('#saveEntries');
    const originalBtnHtml = $saveBtn.html();
    
    // Show loading state on button
    $saveBtn.html(`
        <svg class="animate-spin w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        Saving...
    `).prop('disabled', true).addClass('opacity-75 cursor-not-allowed');
    
    // Prepare the payload
    const payload = {
        action: 'addEntries',
        entries: entries
    };
    
    // Make the API call to Google Apps Script
    fetch(WEB_APP_URL, {
        method: 'POST',
        mode: 'no-cors', // Required for Google Apps Script
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    })
    .then(response => {
        // With no-cors mode, we can't read the response
        // But if we get here, the request was sent successfully
        console.log('📨 POST request sent to Google Apps Script');
        
        // Restore button state
        $saveBtn.html(originalBtnHtml)
            .prop('disabled', false)
            .removeClass('opacity-75 cursor-not-allowed');
        
        // Show success notification
        showNotification(`${entries.length} ${entries.length === 1 ? 'entry' : 'entries'} saved successfully!`, 'success');
        
        // Close the modal
        closeModal();
        
        // Refresh dashboard data after a short delay
        // (give the sheet time to update)
        setTimeout(function() {
            refreshDashboardData();
        }, 1000);
    })
    .catch(error => {
        console.error('❌ Error saving entries:', error);
        
        // Restore button state
        $saveBtn.html(originalBtnHtml)
            .prop('disabled', false)
            .removeClass('opacity-75 cursor-not-allowed');
        
        showNotification('Failed to save entries. Please try again.', 'error');
    });
}

/**
 * Collect entry data from all rows in the modal
 * Loops through each .entry-row and extracts values
 * @returns {Object[]} Array of entry objects with timestamp
 */
function collectEntryData() {
    const entries = [];
    const timestamp = new Date().toISOString();
    const dateString = formatDate(new Date());
    
    // Iterate through each entry row in the modal
    $('#modalBody .entry-row').each(function(index) {
        const $row = $(this);
        
        // Extract values from form fields
        const name = $row.find('input[name="entryName"]').val().trim();
        const amountRaw = $row.find('input[name="entryAmount"]').val();
        const trucksRaw = $row.find('input[name="entryTrucks"]').val();
        const status = $row.find('select[name="entryStatus"]').val();
        
        // Parse numeric values with defaults
        const amount = parseFloat(amountRaw) || 0;
        const truckCount = parseInt(trucksRaw, 10) || 0;
        
        // Only include entries with a name (required field)
        if (name) {
            entries.push({
                name: name,
                amount: amount,
                truckCount: truckCount,
                status: status,
                date: dateString,
                timestamp: timestamp
            });
        }
    });
    
    return entries;
}

/**
 * Refresh dashboard data with current filter
 */
function refreshDashboardData() {
    console.log('🔄 Refreshing dashboard data...');
    
    const { from, to } = AppState.customDateRange;
    
    if (from && to) {
        fetchFilteredData(from, to);
    } else {
        // Default to current filter
        loadDashboardData(AppState.currentFilter);
    }
}

// ============================================
// DASHBOARD UPDATE FUNCTIONS
// ============================================

/**
 * Update entire dashboard with new data from API
 * @param {Object} data - Dashboard data object from API
 */
function updateDashboard(data) {
    console.log('📊 Updating dashboard with new data');
    
    // Update KPI cards
    if (data.summary) {
        updateKPICards(data.summary);
    }
    
    // Update transactions table
    if (data.tableData) {
        updateTransactionsTable(data.tableData);
    }
    
    // Update chart
    if (data.chartData) {
        updateChartData(data.chartData);
    }
}

/**
 * Update KPI cards with new data
 * @param {Object} summary - Summary statistics object
 */
function updateKPICards(summary) {
    // Update Total Trucks
    $('#totalTrucks').text(summary.totalTrucks.toLocaleString());
    
    // Update Revenue Paid
    $('#revenuePaid').text('$' + formatNumber(summary.totalPaid));
    
    // Update Outstanding Amount
    $('#outstandingAmount').text('$' + formatNumber(summary.totalOutstanding));
    
    console.log('📈 KPI cards updated');
}

/**
 * Update transactions table with new data
 * Clears existing rows and populates with new transaction data
 * @param {Object[]} transactions - Array of transaction objects
 */
function updateTransactionsTable(transactions) {
    const $tbody = $('#transactionsBody');
    
    // Clear existing rows
    $tbody.empty();
    
    // Handle empty data
    if (!transactions || transactions.length === 0) {
        $tbody.append(`
            <tr>
                <td colspan="4" class="px-6 py-8 text-center text-slate-500">
                    <svg class="w-12 h-12 mx-auto mb-4 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    <p class="text-lg font-medium">No transactions found</p>
                    <p class="text-sm">Try selecting a different date range or add new entries.</p>
                </td>
            </tr>
        `);
        $('#transactionCount').text('No entries');
        return;
    }
    
    // Populate with new data
    transactions.forEach(function(transaction) {
        const initials = getInitials(transaction.name);
        const isOutstanding = transaction.status === 'Outstanding';
        
        // Determine row styling based on status
        const rowClass = isOutstanding 
            ? 'bg-rose-50/50 hover:bg-rose-50' 
            : 'hover:bg-slate-50';
        const statusBgClass = isOutstanding 
            ? 'bg-rose-100 text-rose-700' 
            : 'bg-emerald-100 text-emerald-700';
        const statusDotClass = isOutstanding 
            ? 'bg-rose-500' 
            : 'bg-emerald-500';
        
        // Format amount
        const formattedAmount = transaction.formattedAmount || ('$' + formatNumber(transaction.amount));
        
        // Create table row HTML
        const rowHtml = `
            <tr class="${rowClass} transition-colors duration-150">
                <td class="px-6 py-4">
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-indigo-100 rounded-full flex items-center justify-center mr-3">
                            <span class="text-sm font-medium text-indigo-600">${escapeHtml(initials)}</span>
                        </div>
                        <span class="font-medium text-slate-800">${escapeHtml(transaction.name)}</span>
                    </div>
                </td>
                <td class="px-6 py-4 text-slate-600">${transaction.truckCount}</td>
                <td class="px-6 py-4 text-slate-800 font-medium">${formattedAmount}</td>
                <td class="px-6 py-4">
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusBgClass}">
                        <span class="w-1.5 h-1.5 ${statusDotClass} rounded-full mr-1.5"></span>
                        ${transaction.status}
                    </span>
                </td>
            </tr>
        `;
        
        $tbody.append(rowHtml);
    });
    
    // Update transaction count display
    $('#transactionCount').text(`Showing ${transactions.length} ${transactions.length === 1 ? 'entry' : 'entries'}`);
    
    console.log('📋 Transactions table updated');
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Show a notification toast message
 * Creates an animated notification that auto-dismisses
 * @param {string} message - Message to display
 * @param {string} type - 'success', 'error', 'warning', or 'info'
 */
function showNotification(message, type = 'info') {
    // Remove any existing notifications first
    $('.notification-toast').remove();
    
    // Define styling based on notification type
    let bgColor, iconPath;
    
    switch (type) {
        case 'success':
            bgColor = 'bg-emerald-500';
            iconPath = 'M5 13l4 4L19 7'; // Checkmark
            break;
        case 'error':
            bgColor = 'bg-rose-500';
            iconPath = 'M6 18L18 6M6 6l12 12'; // X mark
            break;
        case 'warning':
            bgColor = 'bg-amber-500';
            iconPath = 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z'; // Warning triangle
            break;
        default: // info
            bgColor = 'bg-indigo-500';
            iconPath = 'M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z'; // Info circle
    }
    
    // Create notification HTML element
    const $notification = $(`
        <div class="notification-toast fixed top-20 right-4 z-[60] flex items-center px-4 py-3 rounded-lg shadow-lg ${bgColor} text-white transform translate-x-full transition-all duration-300 ease-out max-w-sm">
            <svg class="w-5 h-5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="${iconPath}"></path>
            </svg>
            <span class="font-medium text-sm">${escapeHtml(message)}</span>
            <button class="ml-4 text-white/80 hover:text-white flex-shrink-0 notification-close">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
    `);
    
    // Append to body
    $('body').append($notification);
    
    // Add click handler for close button
    $notification.find('.notification-close').on('click', function() {
        $notification.addClass('translate-x-full opacity-0');
        setTimeout(function() {
            $notification.remove();
        }, 300);
    });
    
    // Trigger slide-in animation
    setTimeout(function() {
        $notification.removeClass('translate-x-full');
    }, 10);
    
    // Auto-dismiss after 4 seconds
    setTimeout(function() {
        $notification.addClass('translate-x-full opacity-0');
        setTimeout(function() {
            $notification.remove();
        }, 300);
    }, 4000);
}

/**
 * Format number with commas and decimal places
 * @param {number} num - Number to format
 * @returns {string} Formatted number string
 */
function formatNumber(num) {
    if (typeof num !== 'number') {
        num = parseFloat(num) || 0;
    }
    return num.toLocaleString('en-US', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
    });
}

/**
 * Get initials from a full name string
 * @param {string} name - Full name
 * @returns {string} Two-letter initials (uppercase)
 */
function getInitials(name) {
    if (!name) return '??';
    
    const words = name.trim().split(/\s+/);
    
    if (words.length >= 2) {
        return (words[0][0] + words[1][0]).toUpperCase();
    }
    
    return name.substring(0, 2).toUpperCase();
}

/**
 * Escape HTML special characters to prevent XSS
 * @param {string} text - Text to escape
 * @returns {string} Escaped text
 */
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ============================================
// KEYBOARD NAVIGATION & ACCESSIBILITY
// ============================================

/**
 * Set up keyboard navigation support
 */
function setupKeyboardNavigation() {
    // Handle Enter key in modal inputs
    $(document).on('keydown', function(e) {
        // Only handle if modal is open
        if ($('#entryModal').hasClass('hidden')) return;
        
        const $activeElement = $(document.activeElement);
        
        // Enter key handling in modal
        if (e.key === 'Enter') {
            // If focus is on an input in an entry row
            if ($activeElement.closest('.entry-row').length) {
                e.preventDefault();
                
                const $currentRow = $activeElement.closest('.entry-row');
                const $lastRow = $('#modalBody .entry-row').last();
                
                // If in the last row, add a new row
                if ($currentRow.is($lastRow)) {
                    addEntryRow();
                } else {
                    // Move to the next row's first input
                    $currentRow.next('.entry-row').find('input[name="entryName"]').focus();
                }
            }
        }
        
        // Tab through modal inputs (standard browser behavior, but ensure last field loops)
        if (e.key === 'Tab' && !e.shiftKey) {
            const $saveBtn = $('#saveEntries');
            if ($activeElement.is($saveBtn)) {
                e.preventDefault();
                $('#modalBody input[name="entryName"]').first().focus();
            }
        }
    });
}

// ============================================
// WINDOW EVENT HANDLERS
// ============================================

/**
 * Handle window resize for responsive chart
 */
$(window).on('resize', function() {
    if (AppState.chart) {
        AppState.chart.resize();
    }
});

/**
 * Handle visibility change (tab switching)
 * Useful for refreshing data when user returns to tab
 */
$(document).on('visibilitychange', function() {
    if (document.visibilityState === 'visible') {
        console.log('👁 Tab became visible');
        // Optionally refresh data when tab becomes visible
        // refreshDashboardData();
    }
});

// ============================================
// DEBUG & DEVELOPMENT HELPERS
// ============================================

/**
 * Expose useful functions and state to window for debugging
 * Can be accessed via browser console: TruckFlow.state, TruckFlow.refreshDashboardData(), etc.
 */
window.TruckFlow = {
    // Application state
    state: AppState,
    
    // API URL
    apiUrl: WEB_APP_URL,
    
    // Modal functions
    openModal: openModal,
    closeModal: closeModal,
    addEntryRow: addEntryRow,
    collectEntryData: collectEntryData,
    
    // Dashboard functions
    updateKPICards: updateKPICards,
    updateTransactionsTable: updateTransactionsTable,
    updateChartData: updateChartData,
    refreshDashboardData: refreshDashboardData,
    fetchFilteredData: fetchFilteredData,
    
    // Utility functions
    showNotification: showNotification,
    formatDate: formatDate,
    
    // Chart functions
    updateChartPeriod: updateChartPeriod,
    
    // Test function to populate with sample data
    loadSampleData: function() {
        const sampleData = {
            status: 'success',
            summary: {
                totalTrucks: 61,
                totalPaid: 17100,
                totalOutstanding: 4000
            },
            tableData: [
                { name: 'ABC Trucking Co.', truckCount: 15, amount: 5500, status: 'Paid' },
                { name: 'Fast Freight LLC', truckCount: 8, amount: 2200, status: 'Outstanding' },
                { name: 'Highway Haulers', truckCount: 12, amount: 4100, status: 'Paid' },
                { name: 'Metro Logistics', truckCount: 6, amount: 1800, status: 'Outstanding' },
                { name: 'National Transport', truckCount: 20, amount: 7500, status: 'Paid' }
            ],
            chartData: {
                labels: generateLast7DaysLabels(),
                paidAmount: [3500, 4200, 2800, 5100, 3900, 4600, 3200],
                outstandingAmount: [800, 1200, 500, 900, 1100, 700, 1300],
                truckCount: [12, 15, 10, 18, 14, 16, 11]
            }
        };
        
        updateDashboard(sampleData);
        showNotification('Sample data loaded', 'success');
    },
    
    // Test API connection
    testAPI: function() {
        console.log('🔍 Testing API connection...');
        fetch(`${WEB_APP_URL}?action=test&filter=today`)
            .then(response => response.json())
            .then(data => {
                console.log('✅ API Response:', data);
                showNotification('API connection successful!', 'success');
            })
            .catch(error => {
                console.error('❌ API Error:', error);
                showNotification('API connection failed', 'error');
            });
    }
};

console.log('🛠 TruckFlow Debug: Access app via window.TruckFlow');
console.log('   Example: TruckFlow.showNotification("Test", "success")');
console.log('   Example: TruckFlow.loadSampleData()');
console.log('   Example: TruckFlow.testAPI()');
console.log('   Example: TruckFlow.refreshDashboardData()');